import React, { } from 'react';

const Home = () => {
    return(
        <>
            <h1 className='h1'>Welcome to Home</h1>
        </>
    )
}

export default Home;