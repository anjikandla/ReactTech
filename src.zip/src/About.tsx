import React, { } from 'react';

const About = () => {
    return(
        <>
            <h1 className='h1'>Welcome to About</h1>
        </>
    )
}

export default About;